# Assimp for Unity

[![Build Status](https://dev.azure.com/intelligide/Assimp%20for%20Unity/_apis/build/status/intelligide.assimp-unity?branchName=master)](https://dev.azure.com/intelligide/Assimp%20for%20Unity/_build/latest?definitionId=3&branchName=master)

## Documentation

[Docs](https://intelligide.github.io/assimp-unity/)

## Contributing

Please take a look at our [contributing](CONTRIBUTING.md) guidelines if you're interested in helping!

## Authors

- Yoann POTINET - [intelligide](https://github.com/intelligide)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details
